+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
City Sky Texture
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

Author: necros
Date: 10.19.01

+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
Description:
A city by night.  Moon near it's Zenith.  Procedural 
texturing at it's fullest on the city itself.

Made in Bryce3D
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
Technical Info:
6 TGAs (24Bit) 512x512 pixels.  No compression
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
Copyright Info:
You are free to use this skybox in any Game, map,
Mod, TC, etc... all I ask is you give me some credit
and drop me a line so I can go check it out!